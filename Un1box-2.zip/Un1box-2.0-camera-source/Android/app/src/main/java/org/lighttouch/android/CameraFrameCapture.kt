package org.lighttouch.android

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.hardware.camera2.CaptureRequest
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import java.nio.ByteBuffer
import kotlin.math.abs
import kotlin.math.ln

/** Converts an Android YUV_420_888 image into tightly packed NV12 (Y, then interleaved UV). */
internal object Yuv420888ToNv12 {
    fun convert(image: Image): ByteArray {
        require(image.format == ImageFormat.YUV_420_888) { "Expected YUV_420_888" }
        val planes = image.planes
        require(planes.size >= 3) { "YUV image has fewer than three planes" }
        return convertPlanes(image.width, image.height,
            planes[0].buffer, planes[0].rowStride, planes[0].pixelStride,
            planes[1].buffer, planes[1].rowStride, planes[1].pixelStride,
            planes[2].buffer, planes[2].rowStride, planes[2].pixelStride)
    }

    internal fun convertPlanes(width: Int, height: Int,
                               y: ByteBuffer, yRowStride: Int, yPixelStride: Int,
                               u: ByteBuffer, uRowStride: Int, uPixelStride: Int,
                               v: ByteBuffer, vRowStride: Int, vPixelStride: Int): ByteArray {
        require(width > 0 && height > 0 && width <= 4096 && height <= 4096 && width % 2 == 0 && height % 2 == 0) { "Invalid image dimensions" }
        val chromaWidth = (width + 1) / 2
        val chromaHeight = (height + 1) / 2
        val yBytes = width * height
        val output = ByteArray(yBytes + chromaWidth * chromaHeight * 2)
        copyPlane(y, yRowStride, yPixelStride, width, height, output, 0)
        val uStart = u.position()
        val vStart = v.position()
        var destination = yBytes
        for (row in 0 until chromaHeight) {
            val uRow = uStart + row * uRowStride
            val vRow = vStart + row * vRowStride
            for (column in 0 until chromaWidth) {
                output[destination++] = u.get(uRow + column * uPixelStride)
                output[destination++] = v.get(vRow + column * vPixelStride)
            }
        }
        return output
    }

    private fun copyPlane(buffer: ByteBuffer, rowStride: Int, pixelStride: Int, width: Int, height: Int,
                          output: ByteArray, offset: Int) {
        val start = buffer.position()
        for (row in 0 until height) {
            val sourceRow = start + row * rowStride
            val destinationRow = offset + row * width
            for (column in 0 until width) {
                output[destinationRow + column] = buffer.get(sourceRow + column * pixelStride)
            }
        }
    }
}

/** Owns one short-lived rear-camera session. The reader queue is deliberately limited to two images. */
internal class CameraFrameCapture(
    context: Context,
    private val submitFrame: (ByteArray, Int, Int) -> Int,
    private val onFailure: (String) -> Unit,
) {
    private val manager = context.getSystemService(CameraManager::class.java)
    @Volatile private var active = false
    @Volatile private var camera: CameraDevice? = null
    @Volatile private var session: CameraCaptureSession? = null
    @Volatile private var reader: ImageReader? = null
    @Volatile private var thread: HandlerThread? = null
    @Volatile private var generation = 0

    @Synchronized
    fun start(): Boolean {
        if (active) return true
        if (manager == null) { onFailure("Camera unavailable: Android has no camera service"); return false }
        if (contextPermissionDenied()) { onFailure("Camera unavailable: CAMERA permission is not granted"); return false }
        val cameraId: String
        val size: android.util.Size
        try {
            cameraId = manager.cameraIdList.firstOrNull { id ->
                manager.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            } ?: run { onFailure("Camera unavailable: no rear-facing camera was found"); return false }
            val characteristics = manager.getCameraCharacteristics(cameraId)
            val map = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
                ?: run { onFailure("Camera unavailable: no stream configuration was reported"); return false }
            size = map.getOutputSizes(ImageFormat.YUV_420_888)
                ?.filter { it.width > 0 && it.height > 0 && it.width <= 1920 && it.height <= 1080 && it.width % 2 == 0 && it.height % 2 == 0 }
                ?.minByOrNull { candidate -> sizeDistance(candidate.width, candidate.height) }
                ?: run { onFailure("Camera unavailable: no even-sized YUV_420_888 stream is supported"); return false }
        } catch (failure: Exception) {
            onFailure("Camera unavailable: ${failure.message ?: "could not inspect camera capabilities"}")
            return false
        }

        val token = ++generation
        val cameraThread = HandlerThread("guest-camera").apply { start() }
        val cameraHandler = Handler(cameraThread.looper)
        val imageReader = try { ImageReader.newInstance(size.width, size.height, ImageFormat.YUV_420_888, 2) }
        catch (failure: Exception) {
            cameraThread.quitSafely()
            onFailure("Camera unavailable: ${failure.message ?: "could not create the image queue"}")
            return false
        }
        thread = cameraThread
        reader = imageReader
        active = true
        imageReader.setOnImageAvailableListener({ source -> consume(source, token) }, cameraHandler)
        try {
            manager.openCamera(cameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(device: CameraDevice) {
                    if (!isCurrent(token)) { device.close(); return }
                    camera = device
                    try {
                        device.createCaptureSession(listOf(imageReader.surface), object : CameraCaptureSession.StateCallback() {
                            override fun onConfigured(captureSession: CameraCaptureSession) {
                                if (!isCurrent(token)) { captureSession.close(); return }
                                session = captureSession
                                try {
                                    val request = device.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                                        addTarget(imageReader.surface)
                                        set(CaptureRequest.CONTROL_MODE, CaptureRequest.CONTROL_MODE_AUTO)
                                    }.build()
                                    captureSession.setRepeatingRequest(request, null, cameraHandler)
                                } catch (failure: Exception) { fail(token, failure) }
                            }
                            override fun onConfigureFailed(captureSession: CameraCaptureSession) {
                                captureSession.close()
                                fail(token, IllegalStateException("camera stream configuration failed"))
                            }
                        }, cameraHandler)
                    } catch (failure: Exception) { fail(token, failure) }
                }
                override fun onDisconnected(device: CameraDevice) {
                    device.close()
                    if (isCurrent(token)) fail(token, IllegalStateException("rear camera disconnected"))
                }
                override fun onError(device: CameraDevice, error: Int) {
                    device.close()
                    if (isCurrent(token)) fail(token, IllegalStateException("camera error $error"))
                }
            }, cameraHandler)
        } catch (failure: Exception) {
            fail(token, failure)
            return false
        }
        return true
    }

    private fun contextPermissionDenied() = manager?.let {
        // CameraManager is acquired from the same service context as this object.
        permissionContext.checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED
    } ?: true

    private val permissionContext = context

    private fun consume(source: ImageReader, token: Int) {
        if (!isCurrent(token)) return
        val image = try { source.acquireLatestImage() } catch (failure: Exception) {
            fail(token, failure); return
        } ?: return
        try {
            if (!isCurrent(token)) return
            val bytes = Yuv420888ToNv12.convert(image)
            val accepted = submitFrame(bytes, image.width, image.height)
            if (accepted < 0) fail(token, IllegalStateException("native camera frame failed ($accepted)"))
        } catch (failure: Exception) { fail(token, failure) }
        finally { image.close() }
    }

    private fun isCurrent(token: Int) = active && generation == token

    private fun fail(token: Int, failure: Exception) {
        if (!isCurrent(token)) return
        active = false
        onFailure("Camera capture stopped: ${failure.message ?: failure.javaClass.simpleName}")
    }

    /** Closes every Camera2 resource before returning; pending callbacks become stale via generation. */
    @Synchronized
    fun stop() {
        active = false
        generation++
        runCatching { session?.stopRepeating() }
        runCatching { session?.close() }
        runCatching { camera?.close() }
        runCatching { reader?.setOnImageAvailableListener(null, null) }
        runCatching { reader?.close() }
        session = null; camera = null; reader = null
        val oldThread = thread
        thread = null
        oldThread?.quitSafely()
        if (oldThread != null && Thread.currentThread() !== oldThread) runCatching { oldThread.join(2_000) }
    }

    private fun sizeDistance(width: Int, height: Int): Double {
        val scaleDistance = abs(ln(width / 640.0)) + abs(ln(height / 480.0))
        val pixelPenalty = abs(width.toLong() * height - 640L * 480L).toDouble() / (640.0 * 480.0)
        return scaleDistance + pixelPenalty * 0.25
    }
}
