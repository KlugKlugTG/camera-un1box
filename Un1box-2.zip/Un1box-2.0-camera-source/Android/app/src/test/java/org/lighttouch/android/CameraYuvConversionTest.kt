package org.lighttouch.android

import java.nio.ByteBuffer
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Test

class CameraYuvConversionTest {
    @Test fun copiesPaddedRowsAndInterleavesChromaAsNv12() {
        val result = Yuv420888ToNv12.convertPlanes(
            width = 4, height = 2,
            y = ByteBuffer.wrap(byteArrayOf(1, 2, 3, 4, 99, 99, 5, 6, 7, 8)), yRowStride = 6, yPixelStride = 1,
            u = ByteBuffer.wrap(byteArrayOf(10, 0, 11)), uRowStride = 4, uPixelStride = 2,
            v = ByteBuffer.wrap(byteArrayOf(20, 0, 21)), vRowStride = 4, vPixelStride = 2,
        )

        assertArrayEquals(byteArrayOf(1, 2, 3, 4, 5, 6, 7, 8, 10, 20, 11, 21), result)
        assertEquals(4 * 2 * 3 / 2, result.size)
    }
}
